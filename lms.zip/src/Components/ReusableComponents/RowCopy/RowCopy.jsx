import React from 'react'

const RowCopy = () => {
  return (
    <div>RowCopy</div>
  )
}

export default RowCopy