import React from "react";

const TeachersTests = () => {
    return <h2>Teachers Test Page 📝</h2>;
};

export default TeachersTests;
