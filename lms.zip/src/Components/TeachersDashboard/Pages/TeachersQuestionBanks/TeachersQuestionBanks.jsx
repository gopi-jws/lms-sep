import React from "react";

const TeachersQuestionBanks = () => {
    return <h2>Teachers Question Banks 📚</h2>;
};

export default TeachersQuestionBanks;
