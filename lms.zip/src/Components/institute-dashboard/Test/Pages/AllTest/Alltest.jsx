import React from 'react'
import './AllTest.css'
import TestIndex from '../../TestIndex/TestIndex';



const Alltest = () => {
  return (
    <div>
    
   
    <TestIndex />
 
    </div>
  );
}

export default Alltest