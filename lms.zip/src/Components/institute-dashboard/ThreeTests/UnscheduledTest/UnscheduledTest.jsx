// src/Components/institute-dashboard/ThreeTests/UnscheduledTest/UnscheduledTest.jsx
import React, { useState, useEffect, useRef } from "react";
import "../CurrentRunningTest/CurrentRunningTest.css";
import DataTable from "../../../ReusableComponents/TableComponent/TableComponent";
import { FileClock } from "lucide-react";
import { VscTriangleDown } from "react-icons/vsc";
import SidebarMenu from "../../dashboard/sidebar/sidemenu";


 const UnscheduledTest = ({ onViewDetails = () => { } }) => {
    const unscheduledTests = [
        {
            id: 1,
            name: "Advanced Mathematics",
            owner: "Dr. Jane Smith",
            doc: "01-01-2025",
            totalAttempts: "99",
            hoursAllotted: 2,
            status: "Writing Now",
            endTime: new Date(Date.now() + 2 * 60 * 60 * 1000),
        },
        {
            id: 2,
            name: "Physics Basics",
            owner: "Dr. John Doe",
            doc: "02-01-2025",
            totalAttempts: "125",
            hoursAllotted: 3,
            status: "Writing Now",
            endTime: new Date(Date.now() + 3 * 60 * 60 * 1000),
        },
        {
            id: 3,
            name: "Chemistry Fundamentals",
            owner: "Dr. Alice Johnson",
            doc: "03-01-2025",
            totalAttempts: "75",
            hoursAllotted: 1.5,
            status: "Writing Now",
            endTime: new Date(Date.now() + 1.5 * 60 * 60 * 1000),
        },
    ];

    const [timeLeft, setTimeLeft] = useState({});
    const [isMobileOpen, setIsMobileOpen] = useState(false);

      // Add refs at the top of your component
      const sidebarRef = useRef(null);
      const toggleRef = useRef(null);
    
      // Close dropdown when clicking outside
      useEffect(() => {
        const handleClickOutside = (e) => {
          // Only handle clicks when sidebar is open
          if (!isMobileOpen) return;
    
          const sidebar = sidebarRef.current;
          const toggle = toggleRef.current;
    
          // If we don't have refs, don't do anything
          if (!sidebar || !toggle) return;
    
          // Check if click is outside both sidebar and toggle button
          const isOutsideSidebar = !sidebar.contains(e.target);
          const isOutsideToggle = !toggle.contains(e.target);
    
          if (isOutsideSidebar && isOutsideToggle) {
            console.log('Closing sidebar - click was outside');
            setIsMobileOpen(false);
          }
        };
    
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
      }, [isMobileOpen]);

     // Mobile toggle function
     const toggleMobileSidebar = () => {
         setIsMobileOpen(!isMobileOpen)
     }


    function calculateTimeLeft(test) {
        const difference = test.endTime.getTime() - new Date().getTime();
        if (difference > 0) {
            return {
                hours: Math.floor((difference / (1000 * 60 * 60)) % 24)
                    .toString()
                    .padStart(2, "0"),
                minutes: Math.floor((difference / 1000 / 60) % 60)
                    .toString()
                    .padStart(2, "0"),
                seconds: Math.floor((difference / 1000) % 60)
                    .toString()
                    .padStart(2, "0"),
            };
        }
        return { hours: "00", minutes: "00", seconds: "00" };
    }

    useEffect(() => {
        const timer = setInterval(() => {
            const updatedTimeLeft = {};
            unscheduledTests.forEach((test) => {
                updatedTimeLeft[test.id] = calculateTimeLeft(test);
            });
            setTimeLeft(updatedTimeLeft);
        }, 1000);

        return () => clearInterval(timer);
    }, []);

     // UnscheduledTest.jsx
     const handleRowClick = (row) => {
         console.log("Row clicked:", row);
         if (typeof onViewDetails === 'function') {
             onViewDetails(row.id);

         } else {
             console.error("onViewDetails is not a function");
         }
      };
    const columns = [
        {
            name: "Test Name",
            selector: "name",
            sortable: true,
        },
        {
            name: "Owner",
            selector: "owner",
            sortable: true,
        },
        {
            name: "Date of Creation",
            selector: "doc",
            sortable: true,
        },
        {
            name: "Total Attempts",
            selector: "totalAttempts",
            sortable: true,
        },
        {
            name: "Status",
            selector: "status",
            cell: (row) => (
                <span className="status-writing">{row.status}</span>
            ),
            sortable: true,
        },
    ];

    return (

        <div className="div">

            <div className="test-index-header-moblie">
                <h1 className="breadcrumb">Unscheduled Tests</h1>
                <VscTriangleDown onClick={toggleMobileSidebar} ref={toggleRef} className="TriagbleDown" />
            </div>

            <div ref={sidebarRef}>
                <SidebarMenu
                    isMobileOpen={isMobileOpen}
                    setIsMobileOpen={setIsMobileOpen}
                />
            </div>
        <div className="current-running-test">
            <div className="status-header">
                <div className="status-title status-title2">
                    <FileClock size={20} className="status-title-icon" />
                    <h3>Unscheduled Tests</h3>
                </div>
            </div>
            <DataTable
                columns={columns}
                data={unscheduledTests}
                onRowClicked={handleRowClick}
                availableActions={[]}
                enableToggle={false}
                showColumnVisibility={false}
                fullViewMode={false}
            />
        </div>
        </div>
    );
};

export default UnscheduledTest;